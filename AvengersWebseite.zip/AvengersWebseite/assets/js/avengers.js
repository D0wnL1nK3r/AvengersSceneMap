var rawData;
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      rawData = JSON.parse(this.responseText);
      console.log(rawData);
    }
};
xhttp.open("GET", "assets/json/avengers.json", true);
xhttp.send(); 

function everything() {
  var insides = "<tr><th>Szenen-ID</th><th>Szenenbeschreibung</th></tr>";
  var  a = rawData.scenes;
  console.log(a);
  for (i = 0; i < a.length; i++) {
    insides += "<tr><td>" +
      a[i].SzenenID +
      "</td><td>" +
      a[i].Szenenbeschreibung +
      "</td><tr>";
  }
  document.getElementById("output1").innerHTML = insides;
}

function drehort() {
  var insides = "<tr><th>Filmtitel</th><th>Szenen-ID</th><th>Drehort</th><th>Drehortbeschreibung</th></tr>";
  var  a = rawData.scenes;
  console.log(a);
  for (i = 0; i < a.length; i++) {
      if (a[i].Drehort !== null) {
        if (a[i].Drehort.match(document.getElementById("drehID").value) !== null) {
          insides += "<tr><td>" +
          a[i].Filmtitel +
          "</td><td>" +
          a[i].SzenenID +
          "</td><td>" +
          a[i].Drehort +
          "</td><td>" +
          a[i].Drehortbeschreibung +
          "</td><tr>";
        }
        else if (a[i].Drehortbeschreibung !== null) {
          if (a[i].Drehortbeschreibung.match(document.getElementById("drehID").value) !== null) {
            insides += "<tr><td>" +
            a[i].Filmtitel +
            "</td><td>" +
            a[i].SzenenID +
            "</td><td>" +
            a[i].Drehort +
            "</td><td>" +
            a[i].Drehortbeschreibung +
            "</td><tr>";
          }
          else {
            continue;
          }
        }
      }
      else if (a[i].Drehortbeschreibung !== null) {
        if (a[i].Drehortbeschreibung.match(document.getElementById("drehID").value) !== null) {
          insides += "<tr><td>" +
          a[i].Filmtitel +
          "</td><td>" +
          a[i].SzenenID +
          "</td><td>" +
          a[i].Drehort +
          "</td><td>" +
          a[i].Drehortbeschreibung +
          "</td><tr>";
        }
        else {
          continue;
        }
      }
      else {
        continue;
      }
  document.getElementById("output2").innerHTML = insides;
  }
}

function szenenort() {
  var insides = "<tr><th>Filmtitel</th><th>Szenen-ID</th><th>Szenenort</th><th>Zeit im Film</th></tr>";
  var  a = rawData.scenes;
  console.log(a);
  for (i = 0; i < a.length; i++) {
      if (a[i].Szenenort !== null) {
        if (a[i].Szenenort.match(document.getElementById("szenenID").value) !== null) {
          insides += "<tr><td>" +
          a[i].Filmtitel +
          "</td><td>" +
          a[i].SzenenID +
          "</td><td>" +
          a[i].Szenenort +
          "</td><td>" +
          a[i].ZeitImFilm +
          "</td><tr>";
        }
      }
      else {
        continue;
      }
  document.getElementById("output3").innerHTML = insides;
  }
}

function charackter() {
  var insides = "<tr><th>Filmtitel</th><th>Szenen-ID</th><th>Szenenbeschreibung</th><th>Figuren</th></tr>";
  var  a = rawData.scenes;
  console.log(document.getElementById("alias").value);
  for (i = 0; i < a.length; i++) {
    if (a[i].Figuren !== null) {
      if (document.getElementById("alias").value == "Alles") {
        console.log("Alles");
        if (a[i].Figuren.match(document.getElementById("char").value) !== null) {
          insides += "<tr><td>" +
          a[i].Filmtitel +
          "</td><td>" +
          a[i].SzenenID +
          "</td><td>" +
          a[i].Szenenbeschreibung +
          "</td><td>" +
          a[i].Figuren +
          "</td><tr>";
        }
        else {
          continue;
        }
      }
      else if (document.getElementById("alias").value == "Zivil") {
        console.log("Zivil");
        if ((a[i].Figuren.match(document.getElementById("char").value) !== null) && (a[i].Figuren.match(document.getElementById("char").value+" als") == null)) {
          insides += "<tr><td>" +
          a[i].Filmtitel +
          "</td><td>" +
          a[i].SzenenID +
          "</td><td>" +
          a[i].Szenenbeschreibung +
          "</td><td>" +
          a[i].Figuren +
          "</td><tr>";
        }
        else {
          continue;
        }
      }
      else if (document.getElementById("alias").value == "Superheld") {
        console.log("Superheld");
        var superheld = document.getElementById("char").value+" als";
        if (a[i].Figuren.match(superheld) !== null) {
          insides += "<tr><td>" +
          a[i].Filmtitel +
          "</td><td>" +
          a[i].SzenenID +
          "</td><td>" +
          a[i].Szenenbeschreibung +
          "</td><td>" +
          a[i].Figuren +
          "</td><tr>";
        }
        else {
          continue;
        }
      }
    }
    else {
      continue;
    }
  document.getElementById("output4").innerHTML = insides;
  }
}

var chars = new Array();
function figuren() {
  var  a = rawData.scenes;
  var output = new Set();
  for (i = 0; i < a.length; i++) {
    if (a[i].Figuren !== null) {
      var figures = a[i].Figuren.split("/");
      chars.push(figures);
    }
    else {
      continue;
    }
  }
  console.log(chars);
}

var flat = new Array();
function flatten(arr) {
  for (var i = 0; i < arr.length; i++) {
      flat = flat.concat(arr[i]);
  }
  console.log(flat);
}

var output = new Set();
function last() {
  for (i = 0; i < flat.length; i++) {
    output.add(flat[i]);
  }
  console.log(output);
}

function display() {
  var display = Array.from(output);
  display.sort();
  document.getElementById("output5").innerHTML =display.join("</br>");
}

function allinone() {
  figuren();
  flatten(chars);
  last();
  display();
}


function reset1() {
  document.getElementById("output1").innerHTML = "";
}

function reset2() {
  document.getElementById("output2").innerHTML = "";
}

function reset3() {
  document.getElementById("output3").innerHTML = "";
}

function reset4() {
  document.getElementById("output4").innerHTML = "";
}

function reset5() {
  document.getElementById("output5").innerHTML = "";
}

function reset6() {
  document.getElementById("output6").innerHTML = "";
}